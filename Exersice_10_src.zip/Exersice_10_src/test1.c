#include <stdio.h>
#include <stdlib.h>
#include "myMalloc.h"

int main() {
  // Get a block that requires exactly one page.
  char *p = malloc( 4088 );
  reportFreeList();
  free( p );
  printf( "--------\n" );
  reportFreeList();
}
