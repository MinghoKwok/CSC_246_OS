#include <stdio.h>
#include <stdlib.h>
#include "myMalloc.h"

int main() {
  // Get a block that requires exactly one page.
  char *p1 = malloc( 1000 );
  char *p2 = malloc( 1000 );
  char *p3 = malloc( 1000 );

  printf( "--------\n" );
  reportFreeList();

  free( p2 );
  free( p1 );

  printf( "--------\n" );
  reportFreeList();

  p2 = malloc( 1500 );

  printf( "--------\n" );
  reportFreeList();
}
