#include <stdio.h>
#include <stdlib.h>
#include "myMalloc.h"

int main() {
  // Get a block that requires exactly one page.
  char *p1 = malloc( 100 );
  char *p2 = malloc( 64 );
  char *p3 = malloc( 200 );
  char *p4 = malloc( 64 );

  printf( "--------\n" );
  reportFreeList();

  free( p1 );
  free( p3 );

  printf( "--------\n" );
  reportFreeList();

  p1 = malloc( 150 );

  printf( "--------\n" );
  reportFreeList();
}
