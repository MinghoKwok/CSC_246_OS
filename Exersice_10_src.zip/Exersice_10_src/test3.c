#include <stdio.h>
#include <stdlib.h>
#include "myMalloc.h"

int main() {
  // Get a block that requires exactly one page.
  char *p1 = malloc( 20 );
  char *p2 = malloc( 40 );
  char *p3 = malloc( 80 );

  printf( "--------\n" );
  reportFreeList();

  free( p3 );
  free( p2 );
  free( p1 );

  printf( "--------\n" );
  reportFreeList();
}
