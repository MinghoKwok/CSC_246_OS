#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>

// Number of iterations for each thread
#define ITERATIONS 500

// Who gets to go next.
int nextTurn = 0;

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

/** Function for the thread on the left. */
void *pingThread( void *arg ) {
  // Repeatedly take turns with the other thread.
  for ( int i = 0; i < ITERATIONS; i++ ) {
    while ( nextTurn != 0 )
      ;

    nextTurn = 1;
  }

  return NULL;
}

/** Function for the thread on the right. */
void *pongThread( void *arg ) {
  // Repeatedly take turns with the other thread.
  for ( int i = 0; i < ITERATIONS; i++ ) {
    while ( nextTurn != 1 )
      ;

    nextTurn = 0;
  }

  return NULL;
}

int main( int argc, char *argv[] ) {
  // Handle for each of our threads.
  pthread_t ping, pong;

  // Make both of our threads.
  if ( pthread_create( &ping, NULL, pingThread, NULL ) != 0 ||
       pthread_create( &pong, NULL, pongThread, NULL ) != 0 ) 
    fail( "Can't create a child thread" );

  // Wait for them both to finish.
  pthread_join( ping, NULL );
  pthread_join( pong, NULL );

  return 0;
}
